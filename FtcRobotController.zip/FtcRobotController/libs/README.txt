Location of external libs
